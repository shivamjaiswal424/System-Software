#ifndef ADMIN_CREDENTIALS
#define ADMIN_CREDENTIALS

#define ADMIN_LOGIN_ID "IIITB"
#define ADMIN_PASSWORD "zxcvbnm" 

#endif